const Paragraph = (props) => {
  console.log("Paragraph Component");
  return <p>{props.children}</p>;
};

export default Paragraph;
